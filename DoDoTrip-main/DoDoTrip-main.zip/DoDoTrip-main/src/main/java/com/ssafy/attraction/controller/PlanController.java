package com.ssafy.attraction.controller;


import com.ssafy.attraction.model.dto.PlanAttractionDto;
import com.ssafy.attraction.model.dto.PlanDto;
import com.ssafy.attraction.model.service.PlanService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class PlanController {

    private final PlanService planService;

    @GetMapping("/plans")
    public Map<String, Object> getPlanList(@RequestParam Map<String, Object> map) {
        return planService.getPlanList(map);
    }

    @GetMapping("/plan/{planNo}")
    public PlanDto getPlan(int planNo) {
        return planService.selectPlan(planNo);
    }

    @PostMapping("/plan")
    public void registPlan(PlanDto planDto) {
        planService.registPlan(planDto);
    }

    @PutMapping("/plan")
    public void updatePlan(@RequestBody PlanDto planDto) {
        planService.updatePlan(planDto);
    }

    @DeleteMapping("/plan/{planno}")
    public void deletePlan(@PathVariable("planno") int planNo) {
        planService.deletePlan(planNo);
    }

    /**
     * Plan Attraction
     */
    @PostMapping("{planId}/attraction")
	public void createPlanAttraction(@RequestBody PlanAttractionDto planAttractionDto, @PathVariable int planNo) throws SQLException {
        planAttractionDto.setPlanPlanNo(planNo);
//		int order = getPlan(planNo).getPlanAttraction
//        planAttractionDto.setOrder(order);
		planService.registPlanAttraction(planAttractionDto);
	}

}
