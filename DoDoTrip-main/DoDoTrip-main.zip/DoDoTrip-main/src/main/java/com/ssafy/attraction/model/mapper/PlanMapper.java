package com.ssafy.attraction.model.mapper;

import com.ssafy.attraction.model.dto.PlanAttractionDto;
import com.ssafy.attraction.model.dto.PlanDto;
import org.apache.ibatis.annotations.Mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Mapper
public interface PlanMapper {

    Map<String, Object> selectPlanList(Map<String, Object> map);

    void insertPlan(PlanDto planDto);

    PlanDto selectPlan(int planNo);

    void updatePlan(PlanDto planDto);

    void deletePlan(int planNo);

    List<PlanAttractionDto> selectPlanAttractionListByPlanNo(int planNo);

    /**
     * PlanAttraction
     */
    PlanAttractionDto selectPlanAttraction(int planAttractionNo) throws SQLException;

    void insertPlanAttraction(PlanAttractionDto planAttractionDto) throws SQLException;

    void updatePlanAttraction(PlanAttractionDto planAttractionDto) throws SQLException;

    void deletePlanAttraction(int planAttractionId) throws SQLException;

}
