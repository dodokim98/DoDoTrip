package com.ssafy.attraction.model.service.impl;

import com.ssafy.attraction.model.dto.PlanAttractionDto;
import com.ssafy.attraction.model.dto.PlanDto;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.attraction.model.mapper.PlanMapper;
import com.ssafy.attraction.model.service.PlanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PlanServiceImpl implements PlanService {

    private final PlanMapper planMapper;

    @Override
    public Map<String, Object> getPlanList(Map<String, Object> map) {
        return planMapper.selectPlanList(map);
    }

    @Override
    public void registPlan(PlanDto planDto) {
        planMapper.insertPlan(planDto);
    }

    @Override
    public PlanDto selectPlan(int planNo) {
        return planMapper.selectPlan(planNo);
    }

    @Override
    public void updatePlan(PlanDto planDto) {
        planMapper.updatePlan(planDto);
    }

    @Override
    public void deletePlan(int planNo) {
        planMapper.deletePlan(planNo);
    }

    @Override
    public List<PlanAttractionDto> getPlanAttraction(int planNo) {
        return planMapper.selectPlanAttractionListByPlanNo(planNo);
    }
    @Override
    public void registPlanAttraction(PlanAttractionDto planAttractionDto) throws SQLException {
        planMapper.insertPlanAttraction(planAttractionDto);
    }

    @Override
    public void modifyPlanAttraction(PlanAttractionDto planAttractionDto) throws SQLException {
        planMapper.updatePlanAttraction(planAttractionDto);
    }
}
