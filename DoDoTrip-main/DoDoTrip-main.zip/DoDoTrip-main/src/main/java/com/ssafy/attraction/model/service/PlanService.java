package com.ssafy.attraction.model.service;

import com.ssafy.attraction.model.dto.PlanAttractionDto;
import com.ssafy.attraction.model.dto.PlanDto;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface PlanService {

    Map<String, Object> getPlanList(Map<String, Object> map);

    void registPlan(PlanDto planDto);

    PlanDto selectPlan(int planNo);

    void updatePlan(PlanDto planDto);

    void deletePlan(int planNo);

    /**
     * PlanAttraction
     */
    List<PlanAttractionDto> getPlanAttraction(int planNo);

    void registPlanAttraction(PlanAttractionDto planAttractionDto) throws SQLException;

    void modifyPlanAttraction(PlanAttractionDto planAttractionDto) throws SQLException;

}
