package com.ssafy.attraction.model.service.impl;

import com.ssafy.attraction.model.dto.AttractionLikeDto;
import com.ssafy.attraction.model.mapper.AttractionLikeMapper;
import org.springframework.stereotype.Service;

@Service
public class AttractionLikeServiceImpl implements AttractionLikeMapper {
    private final AttractionLikeMapper attractionLikeMapper;

    public AttractionLikeServiceImpl(AttractionLikeMapper attractionLikeMapper) {
        super();
        this.attractionLikeMapper = attractionLikeMapper;
    }

    @Override
    public void getAttractionLike(AttractionLikeDto attractionLikeDto) {
        attractionLikeMapper.getAttractionLike(attractionLikeDto);
    }

    @Override
    public void createAttractionLike(AttractionLikeDto attractionLikeDto) {
        attractionLikeMapper.createAttractionLike(attractionLikeDto);
    }

    @Override
    public void deleteAttractionLike(AttractionLikeDto attractionLikeDto) {
        attractionLikeMapper.deleteAttractionLike(attractionLikeDto);
    }


}
