package com.ssafy.attraction.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import com.ssafy.attraction.model.dto.AttractionLikeDto;
import com.ssafy.attraction.model.mapper.AttractionLikeMapper;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class AttractionLikeController {

	private final AttractionLikeMapper attractionLikeMapper;
	
//	@GetMapping(value = "/attractions/{likeNo}")
//	public void getAttractionLike(@RequestBody AttractionLikeDto attractionLikeDto) {
//		attractionLikeMapper.getAttractionLike(attractionLikeDto);
//	}
	
	@PostMapping(value = "/attractions/create")
	public void createAttractionLike(@RequestBody AttractionLikeDto attractionLikeDto) {
		attractionLikeMapper.createAttractionLike(attractionLikeDto);
	}
	
	@DeleteMapping(value = "/attractionos")
	public void deleteAttractionLike(@RequestBody AttractionLikeDto attractionLikeDto) {
		attractionLikeMapper.deleteAttractionLike(attractionLikeDto);
	}
}
