package com.ssafy.attraction.model.mapper;

import com.ssafy.attraction.model.dto.AttractionLikeDto;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AttractionLikeMapper {
    void getAttractionLike(AttractionLikeDto attractionLikeDto);

    void createAttractionLike(AttractionLikeDto attractionLikeDto);

    void deleteAttractionLike(AttractionLikeDto attractionLikeDto);
}
