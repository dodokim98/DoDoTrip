package com.ssafy.attraction.model.service;

import com.ssafy.attraction.model.dto.AttractionLikeDto;

public interface AttractionLikeService {
    void getAttractionLike(AttractionLikeDto attractionLikeDto);

    void createAttractionLike(AttractionLikeDto attractionLikeDto);

    void deleteAttractionLike(AttractionLikeDto attractionLikeDto);
}
