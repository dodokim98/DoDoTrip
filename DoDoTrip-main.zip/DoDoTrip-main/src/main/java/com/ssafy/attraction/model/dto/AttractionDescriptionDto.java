package com.ssafy.attraction.model.dto;

import lombok.Data;

@Data
public class AttractionDescriptionDto {
    private int contentId;
    private String overview;
}
